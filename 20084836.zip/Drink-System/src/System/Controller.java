///Packages///
package System;

///Imports///
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.InvalidParameterException;
import java.util.Optional;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import static System.Drink.full;

///Controller Class///
public class Controller {
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //Fields//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //Saves and loads two objects
    Object[] saveLoad = new Object[2];
    //Hashtable size
    int size = 11;
    //Drinks hashtable
    HashTableSC<Drink> drinkHash = new HashTableSC<Drink>(size);
    //Ingredients hashtable
    HashTableSC<Ingredient> ingredientHash = new HashTableSC<Ingredient>(size);
    //Drinks linked list
    LinkedList<Drink> drinks = new LinkedList<Drink>();
    //Ingredients linked list
    LinkedList<Ingredient> ingredients = new LinkedList<Ingredient>();
    //Drink and ingredient arrays
    Object[] drinkArray, ingArray;
    //Selected ingredient to be viewed
    Ingredient selectedIng;
    //Selected drink to be viewed
    Drink selectedDrink;
    //Collection of tabs
    @FXML
     TabPane tabPane;
    //Each individual tab
    @FXML
     Tab addIng, addDrink, viewDrink, viewIng, updateDelete, searchTab, resetTab, saveLoadTab;
    //All text fields in the system
    @FXML
    TextField drinkName, drinkOrigin, drinkUrl, ingName, ingAlcoContent, ingNameNew, ingAlcoNew, drinkNameNew, drinkOriginNew, drinkUrlNew, searchDrink, searchIngredient;
    //All text areas in the system
    @FXML
    TextArea drinkDescription, ingDescription, ingDescNew, drinkDescNew;
    //All choice boxes in the system
    @FXML
    ChoiceBox selectDrinkDelete, selectDrinkViewDrink, selectDrinkUpdate, drinkIngsViewDrink, relatedDrinksViewIng, selectIngDelete, selectIngUpdate, selectIngViewIng, drinkResults, ingResults;
    //Image area
    @FXML
    ImageView image;
    //Image
    Image pic;
    //Updatable labels
    @FXML
    Label dName, dOrigin, dDescription, iName, iAlcContent, iDescription, alcContent, numMils;
    @FXML
    CheckBox sortAlcContent, sortAlphabetical;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //Methods//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Add drink method///
    public void addDrink() {

        //Creates an array for drink details
        String[] drinkAdd = new String[4];
        drinkAdd[0] = drinkName.getText();
        drinkAdd[1] = drinkDescription.getText();
        drinkAdd[2] = drinkOrigin.getText();
        drinkAdd[3] = drinkUrl.getText();
        ArrayList<IngredientsMils> ingredientsToAdd = new ArrayList<IngredientsMils>();
        int loop = 1;

        //Checks if all fields have been completed
        for (int i = 0; i < drinkAdd.length; i++) {
            String forIf = drinkAdd[i];
            if (forIf.equals("")) {
                //Pop up dialog box prompts for missing information
                TextInputDialog dialog = new TextInputDialog("Default");
                dialog.setTitle(String.valueOf(drinkAdd[i]));
                dialog.setHeaderText("Please enter the missing criteria");
                Optional<String> result = dialog.showAndWait();
                if (result.isPresent()) {
                    drinkAdd[i] = result.get();
                }
            }
        }
        try {
            //Prompts user to add existing ingredient, create ingredient or finish drink
            while (loop == 1) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Drink Information System");
                alert.setHeaderText("Please make a selection");
                ButtonType existing = new ButtonType("Choose existing ingredient");
                ButtonType create = new ButtonType("Create new ingredient");
                ButtonType exit = new ButtonType("Done");
                alert.getButtonTypes().clear();
                alert.getButtonTypes().addAll(existing, create, exit);
                Optional<ButtonType> option = alert.showAndWait();

                if (option.isPresent()) {
                    //Add existing ingredient selected
                    if (option.get() == existing) {
                        loop = 2;
                        //Create ingredient selected
                    } else if (option.get() == create) {
                        loop = 3;
                        //Finish drink
                    }else if (option.get() == exit){
                        loop = 4;
                    }
                }

                while (loop == 2) {
                    //Adds the ingredient to the drink
                    ingredientsToAdd.add(addDrinkSelectedIngredient());
                    loop = 1;
                }
                while (loop == 3) {
                    //Adds created ingredient to the drink
                    ingredientsToAdd.add(addDrinkCreateIngredient());
                    loop = 1;
                }
            }
            //Creates a new drink
            Drink drinkToAdd = new Drink(drinkAdd[0], drinkAdd[1], drinkAdd[2], drinkAdd[3], ingredientsToAdd);
            //Adds drink to the drink list
            drinks.addElement(drinkToAdd);
            //Populates the drink and ingredient dropdowns
            populateDrinks();
            populateIngredients();
            //Hashes the drink and adds it to the hashtable
            drinkHash.add(drinkAdd[0],drinkToAdd);
            //Alerts user that drink was added successfully
            Alert alert = new Alert(Alert.AlertType.INFORMATION); //Informs user that the ingredient was added successfully
            alert.setTitle("Success");
            alert.setHeaderText("Drink Successfully Added");
            alert.showAndWait();

        } catch (Exception E) { throw new InvalidParameterException("None double/integer value in double/integer slot"); }
    }

    ///Add existing Ingredient///
    public IngredientsMils addDrinkSelectedIngredient(){
        //Default volume and alcohol content for selected ingredients
        IngredientsMils ingredientsAdded = new IngredientsMils("DEFAULT", 9999,9999);
        String[] ingredientChoice = new String[ingredients.numElements];
        for(int i = 0;i <  ingredients.numElements; i++) {
            ingredientChoice[i] = ingredients.getElement(i).getName();
        }

        //Prompts user to choose an ingredient
        ChoiceDialog<String> nameDialog = new ChoiceDialog<>(ingredients.getElement(0).getName(),ingredientChoice);
        nameDialog.setTitle("Ingredient Choice");
        nameDialog.setHeaderText("Choose and existing ingredient");
        Optional<String> nameResult = nameDialog.showAndWait();
        if (nameResult.isPresent()){
            String nameSub = nameResult.toString().substring(9, nameResult.toString().length()-1);
            System.out.println("Name: " + nameSub);
            for(int i = 0; i < ingredients.numElements; i++){
                if(ingredients.getElement(i).getName().equals(nameSub)){
                    ingredientsAdded.setName(ingredients.getElement(i).getName());
                    ingredientsAdded.setABV(ingredients.getElement(i).getAlcohol());
                }
            }
        }

        //Prompts user for volume of ingredient in drink
        TextInputDialog milsDialog = new TextInputDialog("200");
        milsDialog.setTitle("Millilitre input");
        milsDialog.setHeaderText("Please enter the ingredient amount in ml");
        Optional<String> milsResult = milsDialog.showAndWait();
        if (milsResult.isPresent()){
            String mils = "";
            mils = milsResult.toString().substring(9, milsResult.toString().length()-1);
            ingredientsAdded.setMils(Integer.parseInt(mils));
        }
        //Returns the ingredient
        return ingredientsAdded;
    }

    ///Creates new ingredient to be added to drink///
    public IngredientsMils addDrinkCreateIngredient() {

        //Default volume and alcohol content for new ingredients
        IngredientsMils ingredientsAdded = new IngredientsMils("DEFAULT", 9999,9999);
        //Default information for new ingredients
        Ingredient ingredientToAdd = new Ingredient("DEFAULT", "DEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULTDEFAULT", 9999);

        //Prompts user for ingredient name
        TextInputDialog nameDialog = new TextInputDialog("Milk");
        nameDialog.setTitle("Name input");
        nameDialog.setHeaderText("Please enter the ingredient name");
        Optional<String> nameResult = nameDialog.showAndWait();
        if (nameResult.isPresent()){
            String name = "";
            name = nameResult.toString().substring(9, nameResult.toString().length()-1);
            ingredientsAdded.setName(name);
            ingredientToAdd.setName(name);
        }

        //Prompts user for ingredient description
        TextInputDialog descDialog = new TextInputDialog("DESCRIPTION");
        descDialog.setTitle("Description input");
        descDialog.setHeaderText("Please enter the ingredient description");
        Optional<String> descResult = descDialog.showAndWait();
        if (nameResult.isPresent()){
            String desc = "";
            desc = descResult.toString().substring(9, descResult.toString().length()-1);
            ingredientToAdd.setDescription(desc);
        }

        //Prompts user for ingredient alcohol content
        TextInputDialog alcDialog = new TextInputDialog("10.00");
        alcDialog.setTitle("Alcohol Input");
        alcDialog.setHeaderText("Please enter the ingredient ABV");
        Optional<String> alcResult = alcDialog.showAndWait();
        if (alcResult.isPresent()){
            String alc = "";
            alc = alcResult.toString().substring(9, alcResult.toString().length()-1);
            ingredientsAdded.setABV(Double.parseDouble(alc));
            ingredientToAdd.setAlcohol(Double.parseDouble(alc));
        }

        //Prompts user for volume of ingredient in drink
        TextInputDialog milsDialog = new TextInputDialog("200");
        milsDialog.setTitle("Millilitre input");
        milsDialog.setHeaderText("Please enter the ingredient amount in ml");
        Optional<String> milsResult = milsDialog.showAndWait();
        if (milsResult.isPresent()){
            String mils = "";
            mils = milsResult.toString().substring(9, milsResult.toString().length()-1);
            ingredientsAdded.setMils(Integer.parseInt(mils));
        }

        //Adds the ingredient to the drink and its hash to the ingredient hashtable
        ingredients.addElement(ingredientToAdd);
        ingredientHash.add(ingredientToAdd.getName(),ingredientToAdd);

        //Alerts the user that the ingredient has been succesfully added
        Alert alert = new Alert(Alert.AlertType.INFORMATION); //Informs user that the ingredient was added successfully
        alert.setTitle("Success");
        alert.setHeaderText("Ingredient SuccessFully Added");
        alert.showAndWait();

        //Returns the ingredient
        return ingredientsAdded;
    }

    ///Updates ingredient///
    public void updateIngredient(){
        //If ingredient is selected
        if(!selectIngUpdate.getSelectionModel().isEmpty()) {
            selectedIng = ingredients.getElement(selectIngUpdate.getSelectionModel().getSelectedIndex());
            Ingredient oldIng = selectedIng;
            String oldName = selectedIng.getName();
            //Updates ingredient name
            if(ingNameNew.getText().length() > 0) {
                selectedIng.setName(ingNameNew.getText());
            }
            //Updates ingredient description
            if(ingDescNew.getText().length() > 0) {
                selectedIng.setDescription(ingDescNew.getText());
            }
            //Updates ingredient alcohol content
            if(ingAlcoNew.getText().length() > 0) {
                selectedIng.setAlcohol(Double.parseDouble(ingAlcoNew.getText()));
            }
            //Updates ingredients' hash if name changes
            ingredientHash.edit(oldName,oldIng,selectedIng.getName(),selectedIng);
            //Populates ingredient drop downs
            populateIngredients();
            full = true;
            System.out.println(selectedIng.toString());
        }
    }

    ///Updates drink information///
    public void updateDrink(){
        //If drink is selected
        if(!selectDrinkUpdate.getSelectionModel().isEmpty()){
            selectedDrink = drinks.getElement(selectDrinkUpdate.getSelectionModel().getSelectedIndex());
            Drink oldDrink = selectedDrink;
            //Update drink name
            String oldName = selectedDrink.getName();
            if (drinkNameNew.getText().length() > 0) {
                selectedDrink.setName(drinkNameNew.getText());
            }
            //Update drink description
            if (drinkDescNew.getText().length() > 0) {
                selectedDrink.setDescription(drinkDescNew.getText());
            }
            //Update drink origin
            if (drinkOriginNew.getText().length() > 0) {
                selectedDrink.setOrigin(drinkOriginNew.getText());
            }
            //Update drink url
            if (drinkUrlNew.getText().length() > 0) {
                selectedDrink.setUrl(drinkUrlNew.getText());
            }
            //Re-hash the drink if name changes
            drinkHash.edit(oldName,oldDrink,selectedDrink.getName(),selectedDrink);
            //Populates drink drop downs
            populateDrinks();
            full = true;
            System.out.println(selectedDrink.toString());
        }
    }

    ///Delete drink///
    public void deleteDrink(){
        //If drink selected
        if(!selectDrinkDelete.getSelectionModel().isEmpty()) {
            //Deletes drinks' hash from drink hashtable
            drinkHash.remove(drinks.getElement(selectDrinkDelete.getSelectionModel().getSelectedIndex()).getName(),drinks.getElement(selectDrinkDelete.getSelectionModel().getSelectedIndex()));
            //Deletes Drink from list
            drinks.deleteElement(selectDrinkDelete.getSelectionModel().getSelectedIndex());
            //Populates drink drop downs
            populateDrinks();
        }
    }

    ///Add ingredient///
    public void addIngredient(){

        //Creates array with new ingredient information
        String[] ingredientAdd = new String[3];
        ingredientAdd[0] = ingName.getText();
        ingredientAdd[1] = ingDescription.getText();
        ingredientAdd[2] = ingAlcoContent.getText();

        //Checks if all fields have been completed
        for (int i = 0; i < ingredientAdd.length; i++) {
            String forIf = ingredientAdd[i];
            if (forIf.equals("")) {
                TextInputDialog dialog = new TextInputDialog("Default");
                dialog.setTitle(String.valueOf(ingredientAdd[i]));
                dialog.setHeaderText("Please enter the missing criteria");
                Optional<String> result = dialog.showAndWait();
                if (result.isPresent()) {
                    ingredientAdd[i] = result.get();
                }
            }
        }
        try {
        Ingredient newIng = new Ingredient(ingredientAdd[0], ingredientAdd[1], Double.parseDouble(ingredientAdd[2]));

        //Adds new ingredient to ingredient list
        ingredients.addElement(newIng);
        full=true;
        System.out.println(ingredients.listElementContents());
        //Populates ingredient drop downs
        populateIngredients();
        //Hashes the ingredient and adds it to the ingredients hashtable
        ingredientHash.add(ingredientAdd[0], newIng);

        //Confirms the ingredient has been added succesfully
        Alert alert = new Alert(Alert.AlertType.INFORMATION); //Informs user that the ingredient was added successfully
        alert.setTitle("Success");
        alert.setHeaderText("Ingredient Successfully Added");
        alert.showAndWait();
        } catch (Exception E) { throw new InvalidParameterException("None double/integer value in double/integer slot"); }

    }

    ///Delete ingredient///
    public void deleteIngredient(){
        //If ingredient selected
        if(!selectIngDelete.getSelectionModel().isEmpty()) {
            //Deletes ingredients' hash from ingredient hashtable
            ingredientHash.remove(ingredients.getElement(selectIngDelete.getSelectionModel().getSelectedIndex()).getName(),ingredients.getElement(selectIngDelete.getSelectionModel().getSelectedIndex()));
            //Deletes ingredient from list
            ingredients.deleteElement(selectIngDelete.getSelectionModel().getSelectedIndex());
            //Populates ingredient drop downs
            populateIngredients();
        }
    }

    ///Populate drink drop downs///
    public void populateDrinks(){
        //Clears every drop down
        selectDrinkDelete.getItems().clear();
        selectDrinkViewDrink.getItems().clear();
        selectDrinkUpdate.getItems().clear();
        //Adds the drink list to an array
        drinkArray = drinks.toArray();
        full=false;
        //Populates every drop down with each drinks name
        for (int m=0; m<drinks.numElements;m++) {
            selectDrinkDelete.getItems().add(drinkArray[m]);
            selectDrinkViewDrink.getItems().add(drinkArray[m]);
            selectDrinkUpdate.getItems().add(drinkArray[m]);
        }
    }

    ///Populate ingredient drop downs///
    public void populateIngredients(){
        //Clears every drop down
        selectIngDelete.getItems().clear();
        selectIngUpdate.getItems().clear();
        selectIngViewIng.getItems().clear();
        //Adds the ingredient list to an array
        ingArray = ingredients.toArray();
        full=false;
        //Populates every drop down with each ingredients name
        for (int m=0; m<ingredients.numElements;m++) {
            selectIngDelete.getItems().add(ingArray[m]);
            selectIngUpdate.getItems().add(ingArray[m]);
            selectIngViewIng.getItems().add(ingArray[m]);
        }
    }

    ///Shows drink information///
    public void drinkInfo(){
        //Gets selected drink
        Drink selectDrink = (Drink) selectDrinkViewDrink.getValue();
        dName.setText(selectDrink.getName());
        dOrigin.setText(selectDrink.getOrigin());
        dDescription.setText(selectDrink.getDescription());
        //Validates url
        if(selectDrink.getUrl().length() > 0 && selectDrink.getUrl().contains("http")) {
            pic = new Image(selectDrink.getUrl());
            image.setImage(pic);
        }
        drinkIngsViewDrink.getItems().clear();
        //Adds drink ingredients to drop down
        for(int i = 0; i < selectDrink.getIngredients().size(); i++) {
            System.out.println("Ing: " + ingredients.getElement(i).getName());
            System.out.println("Mil: " + selectDrink.getIngredients().get(i).getName());
            if(ingredients.getElement(i).getName().equals(selectDrink.getIngredients().get(i).getName()))
            drinkIngsViewDrink.getItems().add(ingredients.getElement(i));
        }
    }

    ///Shows ingredient information///
    public void showIngInfo(){
        //Gets selected ingredient
        Ingredient selectIng = (Ingredient) selectIngViewIng.getValue();
        iName.setText(selectIng.getName());
        iAlcContent.setText(String.valueOf(selectIng.getAlcohol()));
        iDescription.setText(selectIng.getDescription());

        relatedDrinksViewIng.getItems().clear();
        //Adds related drinks to drop down
        for(int i = 0;i < drinks.numElements;i++){
            for(int j = 0;j < drinks.getElement(i).getIngredients().size();j++){
                if(drinks.getElement(i).getIngredients().get(j).getName().equals(selectIng.getName())){
                    relatedDrinksViewIng.getItems().add(drinks.getElement(i));
                }
            }
        }
    }

    ///Go to Drink///
    public void goToDrink() {
        //Gets selected drink and goes to view drink tab
        Drink related =  (Drink) relatedDrinksViewIng.getItems().get(relatedDrinksViewIng.getSelectionModel().getSelectedIndex());
        tabPane.getSelectionModel().select(viewDrink);
        for(int i = 0; i <selectDrinkViewDrink.getItems().size();i++){
            if(selectDrinkViewDrink.getItems().get(i) == related){
                //Shows selected drinks' info
                selectDrinkViewDrink.getSelectionModel().select(i);
                drinkInfo();
            }
        }
    }

    ///Go to ingredient///
    public void goToIng(){
        //Gets selected ingredient and goes to view ingredient tab
        Ingredient related = (Ingredient) drinkIngsViewDrink.getItems().get(drinkIngsViewDrink.getSelectionModel().getSelectedIndex());
        tabPane.getSelectionModel().select(viewIng);
        for(int i = 0 ; i < selectIngViewIng.getItems().size(); i++) {
            if(selectIngViewIng.getItems().get(i) == related){
                //Shows selected drinks' info
                selectIngViewIng.getSelectionModel().select(i);
                showIngInfo();
            }
        }
    }

    ///Show brief ingredient information///
    public void getInformation(){
        //Gets selected drink
        Ingredient related =  (Ingredient) drinkIngsViewDrink.getItems().get(drinkIngsViewDrink.getSelectionModel().getSelectedIndex());
        alcContent.setText(String.valueOf(related.getAlcohol()));
        //Shows volume and alcohol content of ingredient in given drink
        for(int i = 0;i< drinks.numElements;i++){
            for(int j = 0;j< drinks.getElement(i).getIngredients().size();j++){
                if(drinks.getElement(i).getIngredients().get(j).getName().equals(related.getName())){
                    numMils.setText(String.valueOf(drinks.getElement(i).getIngredients().get(j).getMils()));
                }
            }
        }
    }

    ///Search for drink///
    public void searchDrinkB(){
        //Search the user makes
        String search = searchDrink.getText();
        int num=0;
        //Hash is created of search
        for(int i=0;i<search.length();i++){
            num+=search.charAt(i);}
        int hash = num%size;
        Drink retDrinks[] = new Drink[hash];
        drinkResults.getItems().clear();
        for(int i = 0; i < drinkHash.hashSize(hash); i++){
            //Adds each drink with the same hash to the results drop down
            retDrinks[i] = drinkHash.hashGet(hash,i);
        }
        //If to be sorted by alcohol content
        if(sortAlcContent.isSelected()){
            double[] alcArray = new double[retDrinks.length];
            for(int i = 0 ; i < retDrinks.length; i++){
                for(int j = 0; j < retDrinks[i].getIngredients().size(); j++){
                    alcArray[i] += retDrinks[i].getIngredients().get(j).getABV() * retDrinks[i].getIngredients().get(j).getMils();
                }
            }
            boolean sorting = true;
            int index = 0;
            int sortAmount =  0;
            while(sorting){
                if((index + 1) != alcArray.length) {
                    if (alcArray[index] < alcArray[index + 1]) {
                        index++;
                        sortAmount++;
                    }
                    else if (alcArray[index] > alcArray[index + 1]) {
                        sortAmount = 0;
                        double temp = alcArray[index + 1];
                        alcArray[index + 1] = alcArray[index];
                        alcArray[index] = temp;
                        Drink tempDrink = retDrinks[index + 1];
                        retDrinks[index + 1] =  retDrinks[index];
                        retDrinks[index] = tempDrink;
                    }
                }
                else if(sortAmount == alcArray.length - 1){
                    sorting = false;
                }
                else{
                    index = 0;
                }
            }
        }
        else if(sortAlphabetical.isSelected()){

        }

        for(int i = 0; i < drinkHash.hashSize(hash); i++){
            drinkResults.getItems().add(retDrinks[i]);
        }
    }

    ///Search for ingredient///
    public void searchIngredientB(){
        //Search the user makes
        String search = searchIngredient.getText();
        int num=0;
        //Hash is created of search
        for(int i=0;i<search.length();i++){
            num+=search.charAt(i);}
        int hash = num%size;

        Ingredient retIngredient[] = new Ingredient[hash];
        ingResults.getItems().clear();
        //Prints the hash
        System.out.println("Hash: " + hash);
        for(int i = 0; i < ingredientHash.hashSize(hash); i++){
            System.out.println("Integer: " + i);
            //Adds each ingredient with the same hash to the results drop down
            retIngredient[i] = ingredientHash.hashGet(hash,i);
            ingResults.getItems().add(retIngredient[i]);
        }
    }

    ///Go to searched drink///
    public void goToDrink2(){
        Drink res = (Drink) drinkResults.getItems().get(drinkResults.getSelectionModel().getSelectedIndex());
        //Redirects to view drink tab
        tabPane.getSelectionModel().select(viewDrink);
        for(int i = 0 ; i < selectDrinkViewDrink.getItems().size(); i++) {
            if(selectDrinkViewDrink.getItems().get(i) == res){
                //Gets selected drink and shows its info
                selectDrinkViewDrink.getSelectionModel().select(i);
                drinkInfo();
            }
        }
    }

    ///Go to searched ingredient///
    public void goToIng2(){
        Ingredient res = (Ingredient) ingResults.getItems().get(ingResults.getSelectionModel().getSelectedIndex());
        //Redirects to view ingredient tab
        tabPane.getSelectionModel().select(viewIng);
        for(int i = 0 ; i < selectIngViewIng.getItems().size(); i++) {
            if(selectIngViewIng.getItems().get(i) == res){
                //Gets selected ingredient and shows its info
                selectIngViewIng.getSelectionModel().select(i);
                showIngInfo();
            }
        }
    }

    ///Saves the system///
    public void save() throws Exception {
        saveLoad[0] = drinks;
        saveLoad[1] = ingredients;
        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("Drink System.xml"));
        out.writeObject(saveLoad);
        out.close();
    }

    ///Loads the system///
    public void load() throws Exception {
        XStream xstream = new XStream(new DomDriver());
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("Drink System.xml"));
        saveLoad = (Object[]) is.readObject();
        drinks = (LinkedList<Drink>) saveLoad[0];
        ingredients = (LinkedList<Ingredient>) saveLoad[1];
        is.close();
        if(drinks.head != null) {
            populateDrinks();
        }
        if(ingredients.head != null){
            populateIngredients();
        }
    }

    ///Resets the system///
    public void reset(){
        System.out.println("System has been reset");
        //Clears the lists
        drinks.head  = null;
        ingredients.head = null;
        //Clears all drop downs
        selectDrinkDelete.getItems().clear();
        selectDrinkViewDrink.getItems().clear();
        selectIngDelete.getItems().clear();
        selectIngViewIng.getItems().clear();
        selectDrinkUpdate.getItems().clear();
        selectIngUpdate.getItems().clear();
        drinkIngsViewDrink.getItems().clear();
        relatedDrinksViewIng.getItems().clear();
        drinkResults.getItems().clear();
        ingResults.getItems().clear();
        //Clears the text fields
        ingName.clear();
        ingDescription.clear();
        ingAlcoContent.clear();
        drinkName.clear();
        drinkDescription.clear();
        drinkOrigin.clear();
        drinkUrl.clear();
        ingNameNew.clear();
        ingDescNew.clear();
        ingAlcoNew.clear();
        drinkNameNew.clear();
        drinkOriginNew.clear();
        drinkDescNew.clear();
        drinkUrlNew.clear();
        searchDrink.clear();
        searchIngredient.clear();
    }

    ///Quits the program///
    public void quit(){
        System.exit(0);
    }
}
