///Packages///
package System;

///Drink Class///
public class Drink {
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                    //Fields//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Drink details
    private String name, description, origin, url;
    //List of ingredients for each drink
    private ArrayList<IngredientsMils>  ingredients;
    //tostring flag
    public static boolean full=true;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                    //Constructor//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Parameters needed to create a new Drink
    public Drink(String name, String description, String origin, String url, ArrayList<IngredientsMils> ingredients){
        this.name=name;
        this.description=description;
        this.origin=origin;
        this.url=url;
        this.ingredients=ingredients;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                    //Methods//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Show toString///
    @Override
    public String toString() {
        //If flag is true, returns the full tostring
        if (full) {
            return "Drink{" +
                    "name='" + name + '\'' +
                    ", description='" + description + '\'' +
                    ", origin='" + origin + '\'' +
                    ", url='" + url + '\'' +
                    ", ingredients='" + ingredients.get(0) + ingredients.get(1) + ingredients.get(2) +'\'' +
                    '}';
        }
        //If false, returns just the name
        else {
            return name;
        }
    }

    ///Gets drink name///
    public String getName() {
        return name;
    }

    ///Sets drink name///
    public void setName(String name) {
        this.name = name;
    }

    ///Gets drink description///
    public String getDescription() {
        return description;
    }

    ///Sets drink description///
    public void setDescription(String description) {
        this.description = description;
    }

    ///Gets drink origin///
    public String getOrigin() {
        return origin;
    }

    ///Sets drink origin///
    public void setOrigin(String origin) {
        this.origin = origin;
    }

    ///Gets drink url///
    public String getUrl() {
        return url;
    }

    ///Sets drink url///
    public void setUrl(String url) {
        this.url = url;
    }

    ///Gets list of drink ingredients///
    public ArrayList<IngredientsMils> getIngredients() { return ingredients; }

    ///Sets list of drink ingredients///
    public void setIngredients(ArrayList<IngredientsMils> ingredients) { this.ingredients = ingredients; }
}
