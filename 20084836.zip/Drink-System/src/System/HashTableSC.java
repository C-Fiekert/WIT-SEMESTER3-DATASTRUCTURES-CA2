///Packages///
package System;

///HashTableSC Class///
public class HashTableSC<E>{

    LinkedList<E>[] hashTable;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //Constructor//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @SuppressWarnings("unchecked")
    public HashTableSC(int size) {
        hashTable = new LinkedList[size];
        for(int i=0;i<hashTable.length;i++)
            hashTable[i]=new LinkedList<E>();
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //Methods//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Hashes the names of drinks and ingredients///
    public int hashFunctionName(String name){
        //Initially 0
        int num=0;
        //Adds ASCII value of characters together to get total
        for(int i=0;i<name.length();i++){
            num+=name.charAt(i);}
        System.out.println("HASH: " + num%hashTable.length);
        //result of total modulus table length is returned
        return num%hashTable.length;
    }

    ///Adds hash to hashtable///
    public void add(String name, E item){
        hashTable[hashFunctionName(name)].addElement(item);
    }

    ///Removes hash from hashtable///
    public void remove(String name, E item){
        int element = hashFunctionName(name);
        for(int i = 0; i < hashTable[element].numElements; i++)
        if(hashTable[element].getElement(i) == item){
            hashTable[element].deleteElement(i);
        }
    }

    ///Edits hashes for edited drinks and ingredients///
    public void edit(String oldName,E oldItem, String newName, E newItem){
        remove(oldName, oldItem);
        add(newName, newItem);
    }

    ///Returns the hashtable size///
    public int hashSize(int hash){
        return hashTable[hash].numElements;
    }

    ///Gets a given hash from the hashtable///
    public E hashGet(int hash, int element){
        return hashTable[hash].getElement(element);
    }

    /*
    public void displayHashTable() {
        for(int i = 0; i < hashTable.length; i++){
            System.out.println("Chain "+ (i+1));
            System.out.println("<=-=-=-=-=-=-=>");
            for(int j = 0; j < hashTable[i].numElements;j++) {
                System.out.println(hashTable[i].getElement(j).toString());
                System.out.println("<=-=-=-=>");
            }
        }
    }
    */
}
