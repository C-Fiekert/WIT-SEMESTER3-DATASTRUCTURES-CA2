///Packages///
package System;

///Generic Linked List Class///
public class LinkedList<L> {
    //Creates head of linked list
    public LinkedNode<L> head = null;
    //Keeps count of list size
    int numElements = 0;

    ///Add Node Element Method///
    public void addElement(L e) {
        //Creates a new node
        LinkedNode<L> lnode = new LinkedNode<>();
        //Adds desired contents to the node
        lnode.setContents(e);
        //Makes the new node the head
        lnode.next = head;
        head = lnode;
        //Number of nodes increases
        numElements++;
    }

    //Deletes the given node by pointing the preceding node to the node after the node to be deleted
    public void deleteElement(int d){
        //Start at the head
        LinkedNode temp = head;
        if (d == 0){
            head = temp.next;
        }
        else {
            int i = 1;
            //Cycle through list until desired node is found
            while (i < d) {
                temp = temp.next;
                i++;
            }
            //Make node point to the node after the next
            temp.next = temp.next.next;
        }
        numElements--;
    }

    //Gets a given element
    public L getElement(int eNum) {
        //Starts at the head of the list
        LinkedNode element = head;
        //If given object is first in list, return head contents
        if (eNum == 0) {
            return (L)element.getContents();
        }
        //Cycle through list until given object is found
        else if (eNum > 0 && eNum < numElements){
            element = element.next;
            for (int e = 1; e < numElements; e++){
                //When given object is found, return its contents
                if (e == eNum){
                    return (L)element.getContents();
                }
                element=element.next;
            }
        }
        //Otherwise return null
        return null;
    }

    //Returns a list of every nodes contents
    public String listElementContents() {
        //If list is empty, return nothing
        if (head == null) {
            return "";
            //Returns the list of contents
        } else {
            LinkedNode element = head;
            //Creates a toString to list every nodes contents
            String allElements = head.getContents().toString() + "\n";
            //While the next node is not empty, keep adding every nodes contents to the toString
            while (element.next != null) {
                element = element.next;
                allElements = allElements + element.getContents().toString() + "\n";
            }
            //Once the end of the list is reached, return the toString
            return allElements;
        }
    }

    ///Mini Generic Array///
    public Object[] toArray() {
        //If the list is empty, return nothing
        if (numElements == 0) {
            return null;
        } else {
            //Otherwise, create an array the same size as the given list
            Object[] tempArray = new Object[numElements];
            //Add the head to the start of the array
            tempArray[0] = head.getContents();
            //Node follows the head
            LinkedNode tempNode = head.next;
            //Cycle through list and add every node to the array
            for (int i = 1; i < numElements; i++) {
                tempArray[i] = tempNode.getContents();
                tempNode = tempNode.next;
            }
            //Return the array
            return tempArray;
        }
    }

    ///Linked Node Class///
    class LinkedNode<N> {
        //Next is null unless node is added to its position
        public LinkedNode<N> next=null;
        private N contents;

        ///Gets the contents of a node///
        public N getContents() {
            return contents;
        }

        ///Sets the contents of a node///
        public void setContents(N c) {
            contents=c;
        }
    }
}