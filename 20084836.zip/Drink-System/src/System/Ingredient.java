///Packages///
package System;

///Imports///
import static System.Drink.full;

///Ingredient Class///
public class Ingredient {

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //Fields//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Ingredient attributes
    private String name, description;
    private double alcohol;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //Constructor//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Parameters needed to create a new ingredient
    public Ingredient(String name,String description, double alcohol){
         this.name=name;
         this.description=description;
         this.alcohol=alcohol;
    }

    ///Ingredient toString///
    public String toString() {
         if (full) {
             return "Ingredient{" +
                     "name='" + name + '\'' +
                     ", description='" + description + '\'' +
                     ", alcohol=" + alcohol +
                     '}';
         }
         else {
             return name;
         }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //Methods//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Get Name///
    public String getName() {
        return name;
    }

    ///Get Description///
    public String getDescription() { return description; }

    ///Get Alcohol Content///
    public double getAlcohol() { return alcohol; }

    ///Set Name///
    public void setName(String name) {
        this.name = name;
    }

    ///Set Description///
    public void setDescription(String description) { this.description = description; }

    ///Set Alcohol Content///
    public void setAlcohol(double alcohol) { this.alcohol = alcohol; }
}
