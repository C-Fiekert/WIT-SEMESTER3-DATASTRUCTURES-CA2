///Packages///
package System;

///ArrayList Class///
public class ArrayList<A> {
    //Creates an array of size 10
    @SuppressWarnings("unchecked")
    private A[] arrL = (A[]) new Object[10];
    private int index = 0;

    ///Add to array method///
    @SuppressWarnings("unchecked")
    public void add(A item)
    {
        //If array is full, array size is increased by 150%
        if(index >= arrL.length)
        {
            A[] temp = (A[]) new Object[(int) (arrL.length * 1.5 + 1)];
            for (int j = 0; j < arrL.length; j++)
            {
                temp[j] = arrL[j];
            }
            //Creates a new temporary array
            arrL = temp;
        }
        //Adds to given index and increases the index by 1
        arrL[index] = item;
        index++;
    }

    ///Get a position in an array///
    public A get(int input) {
        return arrL[input];
    }

    ///Removes from an array///
    @SuppressWarnings("unchecked")
    public void remove(int input) {
        //Reduces the array size by 1
        A[] tempArrL = (A[]) new Object[arrL.length -1];

        //Cycles through the array
        for (int i = input; i < arrL.length - 1; i++) {
            arrL[i] = arrL[i + 1];
        }
        for(int i = 0; i < tempArrL.length; i++){
            tempArrL[i] = arrL[i];
        }
        arrL = tempArrL;
        index--;
    }

    ///Gets array size///
    public int size() {
        return index;
    }
}
