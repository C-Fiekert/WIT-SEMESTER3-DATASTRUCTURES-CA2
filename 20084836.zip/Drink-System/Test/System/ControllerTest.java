package System;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ControllerTest {

    private ArrayList<String> testArray= new ArrayList<String>();

    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown(){
        testArray = null;
    }

    @Test
    public void arrayListTest() {
        Assert.assertNull(testArray);
    }
}